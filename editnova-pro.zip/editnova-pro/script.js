const $=s=>document.querySelector(s),uid=()=>Math.random().toString(36).slice(2,9);
const st={get(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}},set(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
let set=Object.assign({theme:'dark',fps:30,res:'1280x720'},st.get('en_set',{}));
let S={id:null,name:'',w:1280,h:720,clips:[],media:[],sel:null,t:0,playing:false},zoom=60,tool='v',hist=[],redo=[],blobs={},els={},ac,dst,rec=null,last=0,page='home',cap=null;
const cv=$('#cv'),g=cv.getContext('2d'),off=document.createElement('canvas'),og=off.getContext('2d',{willReadFrequently:true});
const FX={none:'',bw:' grayscale(1)',sepia:' sepia(.9)',warm:' sepia(.35) saturate(1.3)',cool:' hue-rotate(25deg) saturate(1.1)',blur:' blur(4px)'};
const ROWS=[1,0,2,3];
function toast(m){const t=$('#toast');t.textContent=m;t.style.display='block';clearTimeout(t.h);t.h=setTimeout(()=>t.style.display='none',2600)}
function theme(){document.documentElement.dataset.theme=set.theme}theme();
/* navigation */
function nav(p){if(p=='editor'&&!S.id)return newProject('Untitled project');page=p;document.body.dataset.page=p;document.querySelectorAll('.page').forEach(e=>e.classList.toggle('on',e.id==p));
 document.querySelectorAll('#menu a').forEach(a=>a.classList.toggle('cur',a.dataset.p==p));$('#menu').classList.remove('on');$('#sv').style.display=p=='editor'?'':'none';
 if(p=='home')rHome();if(p=='projects')rProj();if(p=='settings')rSet();if(p=='studio')dInit();if(p=='templates')rTpls();if(p=='editor'){fit();rAll()}}
$('#mb').onclick=e=>{e.stopPropagation();$('#menu').classList.toggle('on')};document.onclick=()=>$('#menu').classList.remove('on');
document.querySelectorAll('#menu a').forEach(a=>a.onclick=()=>nav(a.dataset.p));
/* projects */
const plist=()=>st.get('en_proj',[]);
function saveP(q){if(!S.id)return;const l=plist().filter(p=>p.id!==S.id);l.unshift({id:S.id,name:S.name,w:S.w,h:S.h,upd:Date.now(),clips:S.clips,media:S.media.map(({id,name,type,dur})=>({id,name,type,dur}))});st.set('en_proj',l);if(!q)toast('Project saved')}
function newProject(name,w,h){const [dw,dh]=set.res.split('x').map(Number);load({id:uid(),name:name||'Untitled project',w:w||dw,h:h||dh,clips:[],media:[]});saveP(1)}
function load(p){pause();Object.values(els).forEach(e=>{try{e.el.pause()}catch(_){}});els={};
 S={id:p.id,name:p.name,w:p.w,h:p.h,clips:JSON.parse(JSON.stringify(p.clips)),media:p.media.map(m=>({...m,url:blobs[m.id]||null})),sel:null,t:0,playing:false};hist=[];redo=[];nav('editor')}
function fit(){cv.width=S.w;cv.height=S.h;off.width=S.w;off.height=S.h;$('#pn').textContent='— '+S.name}
function card(p,full){const d=document.createElement('div');d.className='card';d.innerHTML=`<div class="ico">🎞</div><b>${p.name.replace(/</g,'&lt;')}</b><div class="mu">${p.w}×${p.h} · ${p.clips.length} clips<br>${new Date(p.upd).toLocaleString()}</div>`;
 const b=(t,f)=>{const x=document.createElement('button');x.textContent=t;x.style.margin='8px 6px 0 0';x.onclick=f;d.append(x)};
 b('Open',()=>load(p));if(full){b('Rename',()=>{const n=prompt('New name',p.name);if(n){const l=plist();l.find(x=>x.id==p.id).name=n;st.set('en_proj',l);if(S.id==p.id)S.name=n;rProj()}});
 b('Duplicate',()=>{const l=plist();l.unshift({...JSON.parse(JSON.stringify(p)),id:uid(),name:p.name+' copy',upd:Date.now()});st.set('en_proj',l);rProj()});
 b('Delete',()=>{if(confirm('Delete this project?')){st.set('en_proj',plist().filter(x=>x.id!=p.id));if(S.id==p.id)S.id=null;rProj()}})}return d}
function rHome(){const r=$('#rec');r.innerHTML='';const l=plist().slice(0,4);if(!l.length)r.innerHTML='<p class="mu">No projects yet. Create one to get started.</p>';l.forEach(p=>r.append(card(p)));
 const t=$('#tpl');t.innerHTML='';[['YouTube 16:9',1280,720,'▶'],['Shorts / Reels 9:16',720,1280,'📱'],['Square 1:1',1080,1080,'⬛'],['Cinema 21:9',1680,720,'🎬']].forEach(([n,w,h,i])=>{const d=document.createElement('div');d.className='card t';d.innerHTML=`<div class="ico">${i}</div><b>${n}</b><div class="mu">${w}×${h}</div>`;d.onclick=()=>newProject(n,w,h);t.append(d)})}
function rProj(){const r=$('#pl');r.innerHTML='';const l=plist();if(!l.length)r.innerHTML='<p class="mu">No saved projects.</p>';l.forEach(p=>r.append(card(p,1)))}
function rSet(){$('#sth').value=set.theme;$('#sfps').value=set.fps;$('#sres').value=set.res;$('#sto').textContent='Saved projects use about '+(((localStorage.getItem('en_proj')||'').length)/1024).toFixed(1)+' KB of browser storage.'}
$('#cp').onclick=()=>{const n=prompt('Project name','My first edit');if(n!==null)newProject(n)};
$('#sth').onchange=e=>{set.theme=e.target.value;st.set('en_set',set);theme()};
$('#sfps').onchange=e=>{set.fps=+e.target.value;st.set('en_set',set)};$('#sres').onchange=e=>{set.res=e.target.value;st.set('en_set',set)};
$('#clr').onclick=()=>{if(confirm('Delete ALL projects?')){st.set('en_proj',[]);rSet()}};$('#sv').onclick=()=>saveP();
setInterval(()=>{if(page=='editor')saveP(1)},5000);
/* history */
const snap=()=>JSON.stringify(S.clips);
function push(){hist.push(snap());if(hist.length>60)hist.shift();redo=[]}
function undo(){if(!hist.length)return;redo.push(snap());S.clips=JSON.parse(hist.pop());S.sel=null;rAll()}
function redoF(){if(!redo.length)return;hist.push(snap());S.clips=JSON.parse(redo.pop());S.sel=null;rAll()}
/* media */
$('#imp').onclick=()=>$('#fi').click();
$('#fi').onchange=e=>{[...e.target.files].forEach(f=>{const url=URL.createObjectURL(f),type=f.type.startsWith('audio')?'audio':f.type.startsWith('image')?'image':'video';
 const done=dur=>{const o=S.media.find(m=>m.name==f.name&&!m.url);if(o){o.url=url;blobs[o.id]=url;o.dur=dur}else{const id=uid();blobs[id]=url;S.media.push({id,name:f.name,type,dur,url})}rBin();frame()};
 if(type=='image')return done(5);const m=document.createElement(type=='audio'?'audio':'video');m.preload='metadata';m.onloadedmetadata=()=>done(m.duration||5);m.src=url});e.target.value=''};
function rBin(){const b=$('#bin');b.innerHTML=S.media.length?'':'<p class="mu">Click Import to add video, audio or images. Double-click an item to add it to the timeline.</p>';
 S.media.forEach(m=>{const d=document.createElement('div');d.className='mi';d.draggable=true;d.innerHTML=`<span class="ico" style="font-size:20px">${{video:'🎞',audio:'🎵',image:'🖼'}[m.type]}</span><div style="min-width:0"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${m.name.replace(/</g,'&lt;')}</div><small>${m.dur.toFixed(1)}s ${m.url?'':'<span class=off>offline: re-import</span>'}</small></div>`;
 d.ondragstart=e=>e.dataTransfer.setData('text/plain',m.id);d.ondblclick=()=>{const tr=m.type=='audio'?3:0;addClip(m,tr,Math.max(0,...S.clips.filter(c=>c.tr==tr).map(c=>c.s+c.d)))};b.append(d)})}
function mk(o){return Object.assign({id:uid(),mid:null,tr:0,s:0,in:0,d:3,br:100,co:100,sa:100,op:100,sc0:100,sc1:100,x0:0,x1:0,spd:1,vol:1,tn:'none',td:.6,fx:'none',ck:0,ckc:'#00ff00',ckt:40,text:'',size:56,col:'#ffffff'},o)}
function addClip(m,tr,s){push();const c=mk({mid:m.id,tr,s,d:m.dur});S.clips.push(c);S.sel=c.id;rAll()}
function addText(text,s,d){const c=mk({tr:2,s,d,text});S.clips.push(c);return c}
/* audio graph */
function initAC(){if(ac)return;ac=new(window.AudioContext||window.webkitAudioContext)();dst=ac.createMediaStreamDestination()}
function getEl(c){if(els[c.id])return els[c.id];const m=S.media.find(x=>x.id==c.mid);if(!m||!m.url)return null;let e;
 if(m.type=='image'){const i=new Image();i.onload=()=>frame();i.src=m.url;e={el:i,v:0}}else{initAC();const v=document.createElement(m.type=='audio'?'audio':'video');v.src=m.url;v.preload='auto';v.onseeked=()=>frame();v.onloadeddata=()=>frame();
  const gn=ac.createGain();try{ac.createMediaElementSource(v).connect(gn)}catch(_){}gn.connect(ac.destination);gn.connect(dst);e={el:v,v:1,gain:gn}}return els[c.id]=e}
function sync(seek){for(const c of S.clips){if(c.tr==2)continue;const e=getEl(c);if(!e||!e.v)continue;const a=S.t>=c.s&&S.t<c.s+c.d,v=e.el;
 if(a){const w=c.in+(S.t-c.s)*c.spd;v.playbackRate=c.spd;if(seek||Math.abs(v.currentTime-w)>.3)v.currentTime=w;
  if(S.playing&&v.paused)v.play().catch(()=>{});if(!S.playing&&!v.paused)v.pause();
  const f=c.tn=='none'?1:Math.min(1,(S.t-c.s)/c.td,(c.s+c.d-S.t)/c.td);e.gain.gain.value=c.vol*Math.max(0,f)}
 else{if(!v.paused)v.pause();e.gain.gain.value=0}}}
/* render */
const total=()=>Math.max(0,...S.clips.map(c=>c.s+c.d));
const tcf=t=>{const f=set.fps,n=Math.floor(t*f),p=x=>String(x).padStart(2,'0');return p(Math.floor(n/f/60))+':'+p(Math.floor(n/f)%60)+':'+p(n%f)};
function draw(c){const W=cv.width,H=cv.height,u=S.t-c.s,o=c.s+c.d-S.t,k=c.d?u/c.d:0;let p=1,al=c.op/100;if(c.tn!='none'){p=Math.min(1,u/c.td);al*=Math.max(0,Math.min(1,o/c.td))}
 const sc=(c.sc0+(c.sc1-c.sc0)*k)/100,x=(c.x0+(c.x1-c.x0)*k)/100*W;g.save();
 if(c.tn=='fade')al*=p;if(c.tn=='wipe'){g.beginPath();g.rect(0,0,W*p,H);g.clip()}if(c.tn=='slide')g.translate((p-1)*W,0);g.globalAlpha=Math.max(0,Math.min(1,al));
 if(c.tr==2){g.translate(W/2+x,H*.86);g.scale(sc,sc);g.font=`700 ${c.size*H/720}px system-ui,sans-serif`;g.textAlign='center';g.fillStyle=c.col;g.strokeStyle='#000';g.lineWidth=6;g.lineJoin='round';g.strokeText(c.text,0,0);g.fillText(c.text,0,0)}
 else{const e=getEl(c);const el=e&&e.el;const sw=el&&(el.videoWidth||el.naturalWidth),sh=el&&(el.videoHeight||el.naturalHeight);
  if(sw&&sh){const r=Math.min(W/sw,H/sh),w=sw*r,h=sh*r;g.translate(W/2+x,H/2);g.scale(sc,sc);g.filter=`brightness(${c.br}%) contrast(${c.co}%) saturate(${c.sa}%)`+FX[c.fx];
   if(c.ck){og.clearRect(0,0,W,H);og.drawImage(el,0,0,w,h);const id=og.getImageData(0,0,Math.ceil(w),Math.ceil(h)),d=id.data,R=parseInt(c.ckc.slice(1,3),16),G=parseInt(c.ckc.slice(3,5),16),B=parseInt(c.ckc.slice(5,7),16),th=c.ckt*2.5;
    for(let i=0;i<d.length;i+=4)if(Math.hypot(d[i]-R,d[i+1]-G,d[i+2]-B)<th)d[i+3]=0;og.putImageData(id,0,0);g.drawImage(off,0,0,w,h,-w/2,-h/2,w,h)}
   else g.drawImage(el,-w/2,-h/2,w,h)}}g.restore()}
function frame(){g.globalAlpha=1;g.filter='none';g.fillStyle='#000';g.fillRect(0,0,cv.width,cv.height);
 for(const tr of[0,1,2])for(const c of S.clips)if(c.tr==tr&&S.t>=c.s&&S.t<c.s+c.d)draw(c);$('#tc').textContent=tcf(S.t);
 const p=$('#ph');if(p)p.style.left=S.t*zoom+'px'}
function loop(ts){if(page=='editor'){if(S.playing){S.t+=(ts-last)/1000;if(S.t>=total()){S.t=total();pause();if(rec){rec.stop();rec=null}}else sync(false)}frame()}last=ts;requestAnimationFrame(loop)}
requestAnimationFrame(loop);
function play(){initAC();ac.resume();if(S.t>=total())S.t=0;S.playing=true;sync(true);$('#bp').textContent='⏸ Pause'}
function pause(){S.playing=false;sync(false);$('#bp').textContent='▶ Play'}
function seek(t){S.t=Math.max(0,t);sync(true);frame()}
$('#bp').onclick=()=>S.playing?pause():play();$('#b0').onclick=()=>seek(0);$('#b1').onclick=()=>seek(total());
/* timeline */
function rTL(){const W=Math.max(total()+15,40)*zoom,tl=$('#tlin');tl.style.width=W+'px';tl.innerHTML='';
 const r=document.createElement('div');r.className='ruler';const step=zoom<30?10:zoom<80?5:1;for(let s=0;s*zoom<W;s+=step){const i=document.createElement('i');i.style.left=s*zoom+'px';i.textContent=s+'s';r.append(i)}
 r.onpointerdown=e=>{const mv=ev=>seek((ev.clientX-r.getBoundingClientRect().left)/zoom);mv(e);r.setPointerCapture(e.pointerId);r.onpointermove=mv;r.onpointerup=()=>r.onpointermove=null};tl.append(r);
 ROWS.forEach(tr=>{const row=document.createElement('div');row.className='trk';
  row.ondragover=e=>e.preventDefault();row.ondrop=e=>{e.preventDefault();const m=S.media.find(x=>x.id==e.dataTransfer.getData('text/plain'));if(m)addClip(m,tr,Math.max(0,(e.clientX-row.getBoundingClientRect().left)/zoom))};
  S.clips.filter(c=>c.tr==tr).forEach(c=>{const m=S.media.find(x=>x.id==c.mid),d=document.createElement('div');d.className='clip t'+tr+(S.sel==c.id?' sel':'');d.style.left=c.s*zoom+'px';d.style.width=Math.max(8,c.d*zoom)+'px';
   d.append(c.tr==2?'T: '+c.text:(m?m.name:'?'));const h=document.createElement('div');h.className='h';d.append(h);
   d.onpointerdown=e=>{e.stopPropagation();if(tool=='c'&&e.target!=h){split(c,c.s+(e.clientX-d.getBoundingClientRect().left)/zoom);return}
    S.sel=c.id;document.querySelectorAll('.clip').forEach(x=>x.classList.remove('sel'));d.classList.add('sel');rProps();push();
    const x0=e.clientX,s0=c.s,d0=c.d,trim=e.target==h;d.setPointerCapture(e.pointerId);
    d.onpointermove=ev=>{const dx=(ev.clientX-x0)/zoom;if(trim){let nd=Math.max(.2,d0+dx);if(m&&m.type!='image')nd=Math.min(nd,(m.dur-c.in)/c.spd);c.d=nd;d.style.width=nd*zoom+'px'}else{c.s=Math.max(0,s0+dx);d.style.left=c.s*zoom+'px'}};
    d.onpointerup=()=>{d.onpointermove=null;rTL();sync(true);frame()}};row.append(d)});tl.append(row)});
 const ph=document.createElement('div');ph.id='ph';tl.append(ph);ph.style.left=S.t*zoom+'px'}
function split(c,t){if(!c||t<=c.s+.05||t>=c.s+c.d-.05)return toast('Move the playhead inside the clip first');push();const c2=JSON.parse(JSON.stringify(c));c2.id=uid();c2.in=c.in+(t-c.s)*c.spd;c2.s=t;c2.d=c.s+c.d-t;c.d=t-c.s;S.clips.push(c2);rAll();sync(true)}
function splitAt(){const c=S.clips.find(x=>x.id==S.sel)||S.clips.find(x=>S.t>x.s&&S.t<x.s+x.d);split(c,S.t)}
function delSel(){if(!S.sel)return;push();S.clips=S.clips.filter(c=>c.id!=S.sel);S.sel=null;rAll()}
$('#sp2').onclick=splitAt;$('#del').onclick=delSel;$('#un').onclick=undo;$('#re').onclick=redoF;
$('#tv').onclick=()=>tool='v';$('#tcut').onclick=()=>tool='c';$('#zm').oninput=e=>{zoom=+e.target.value;rTL()};
$('#ti').onclick=()=>{push();const c=addText('Your title here',S.t,3);S.sel=c.id;rAll()};
$('#ac2').onclick=()=>{const R=window.SpeechRecognition||window.webkitSpeechRecognition;if(!R)return toast('Speech recognition is not supported in this browser');
 if(cap){cap.stop();cap=null;return toast('Auto captions stopped')}cap=new R();cap.continuous=true;cap.interimResults=false;
 cap.onresult=e=>{const x=e.results[e.results.length-1][0].transcript.trim();if(x){push();addText(x,S.t,2.5);rAll()}};cap.onend=()=>cap=null;cap.start();play();toast('Listening via microphone. Captions appear at the playhead. Click again to stop.')};
/* properties */
const DEF=[['Color grading'],['br','Brightness',0,200,1],['co','Contrast',0,200,1],['sa','Saturation',0,300,1],['Keyframes (start → end)'],['sc0','Scale start',10,300,1],['sc1','Scale end',10,300,1],['x0','X start',-100,100,1],['x1','X end',-100,100,1],['op','Opacity',0,100,1],['Speed & audio'],['spd','Speed',.25,4,.25],['vol','Volume',0,2,.05]];
function rProps(){const p=$('#props'),c=S.clips.find(x=>x.id==S.sel);if(!c){p.innerHTML='<p class="mu">Select a clip on the timeline to edit it.</p>';return}p.innerHTML='';
 const add=h=>{const d=document.createElement('div');d.innerHTML=h;p.append(...d.childNodes)};
 if(c.tr==2)add(`<div class="sec">Title</div><div class="f"><label>Text</label><input type="text" id="p_text"></div><div class="f"><label>Size</label><input type="range" id="p_size" min="20" max="160"><span></span></div><div class="f"><label>Color</label><input type="color" id="p_col"></div>`);
 DEF.forEach(r=>{if(r.length==1)return add(`<div class="sec">${r[0]}</div>`);if(c.tr==2&&['br','co','sa','spd','vol'].includes(r[0]))return;add(`<div class="f"><label>${r[1]}</label><input type="range" id="p_${r[0]}" min="${r[2]}" max="${r[3]}" step="${r[4]}"><span id="v_${r[0]}"></span></div>`)});
 add(`<div class="sec">Transition & filter</div><div class="f"><label>In/Out</label><select id="p_tn"><option value="none">None</option><option value="fade">Fade</option><option value="wipe">Wipe</option><option value="slide">Slide</option></select></div>`);
 if(c.tr<2)add(`<div class="f"><label>Filter</label><select id="p_fx">${Object.keys(FX).map(k=>`<option>${k}</option>`).join('')}</select></div><div class="sec">Green screen</div><div class="f"><label>Enable</label><input type="checkbox" id="p_ck"></div><div class="f"><label>Key color</label><input type="color" id="p_ckc"></div><div class="f"><label>Tolerance</label><input type="range" id="p_ckt" min="5" max="100"><span></span></div>`);
 p.querySelectorAll('[id^=p_]').forEach(el=>{const k=el.id.slice(2);if(el.type=='checkbox')el.checked=!!c[k];else el.value=c[k];const sh=()=>{const v=$('#v_'+k);if(v)v.textContent=c[k]};sh();
  el.onpointerdown=el.onfocus=()=>push();el.oninput=()=>{c[k]=el.type=='checkbox'?+el.checked:(el.type=='range'?+el.value:el.value);sh();if(k=='text'||k=='spd'||k=='vol')rTL();sync(false);frame()}})}
function rAll(){rBin();rTL();rProps();frame()}
/* export */
$('#ex').onclick=()=>{if(!window.MediaRecorder)return toast('Export is not supported in this browser');if(!total())return toast('Add clips first');pause();initAC();ac.resume();
 const [w,h]=[S.w,S.h],stream=cv.captureStream(set.fps);dst.stream.getAudioTracks().forEach(t=>stream.addTrack(t));
 const mime=['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'].find(m=>MediaRecorder.isTypeSupported(m));const ch=[];
 rec=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:8e6});rec.ondataavailable=e=>e.data.size&&ch.push(e.data);
 rec.onstop=()=>saveFile(new Blob(ch,{type:'video/webm'}),S.name.replace(/\W+/g,'_')+'.webm');
 seek(0);rec.start();play();toast('Rendering in real time. Keep this tab open.')};
/* keys */
document.onkeydown=e=>{if(page!='editor'||/INPUT|SELECT|TEXTAREA/.test(e.target.tagName))return;const k=e.key.toLowerCase();
 if(k==' '){e.preventDefault();S.playing?pause():play()}else if(k=='s'&&(e.ctrlKey||e.metaKey)){e.preventDefault();saveP()}else if(k=='s')splitAt();else if(k=='v')tool='v';else if(k=='c')tool='c';
 else if(k=='delete'||k=='backspace')delSel();else if(k=='z'&&(e.ctrlKey||e.metaKey)){e.preventDefault();undo()}else if(k=='y'&&(e.ctrlKey||e.metaKey)){e.preventDefault();redoF()}
 else if(k=='arrowleft')seek(S.t-1/set.fps);else if(k=='arrowright')seek(S.t+1/set.fps)};
/* AI image maker */
let aiSvg=null,aiCtl=null;const aiEl=$('#aim');
$('#aib').onclick=()=>{if(!S.id)return toast('Open a project first');aiEl.classList.add('on')};
$('#aix').onclick=()=>{aiEl.classList.remove('on');if(aiCtl)aiCtl.abort()};
function hsh(s){let h=2166136261;for(const ch of s){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}
function fbSvg(p,W,H){let h=hsh(p);const r=()=>(h=Math.imul(h^h>>>15,2246822507)>>>0,h/4294967296),hue=r()*360,c=(a,l)=>`hsl(${(hue+a)%360} 80% ${l}%)`;
 let s=`<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 ${W} ${H}'><defs><linearGradient id='g' x1='0' y1='0' x2='0' y2='1'><stop offset='0' stop-color='${c(0,16)}'/><stop offset='.6' stop-color='${c(60,42)}'/><stop offset='1' stop-color='${c(160,58)}'/></linearGradient><filter id='b'><feGaussianBlur stdDeviation='${W/60}'/></filter></defs><rect width='${W}' height='${H}' fill='url(#g)'/>`;
 for(let i=0;i<90;i++)s+=`<circle cx='${r()*W}' cy='${r()*H*.6}' r='${r()*W/300+1}' fill='#fff' opacity='${r()*.8}'/>`;
 s+=`<circle cx='${W*(.2+r()*.6)}' cy='${H*.35}' r='${H*.14}' fill='${c(200,80)}' filter='url(#b)'/>`;
 for(let k=0;k<4;k++){const y=H*(.55+k*.1);let d=`M0 ${H}L0 ${y}`;for(let x=0;x<=W;x+=W/12)d+=`L${x} ${y-r()*H*.18}`;s+=`<path d='${d}L${W} ${H}Z' fill='${c(220+k*20,30-k*6)}' opacity='${.5+k*.15}'/>`}return s+'</svg>'}
$('#aig').onclick=async()=>{const p=$('#aip').value.trim();if(!p)return toast('Describe the image first');const W=S.w,H=S.h,b=$('#aig'),st=$('#ais');b.disabled=true;st.textContent='Painting with AI...';let svg=null,mode='AI';
 try{const smp=window.claude&&await window.claude.use('sample');if(smp){aiCtl=new AbortController();const r=await smp(`You are a world-class vector illustrator. Create a stunning ${$('#ast').value} image of: "${p}".\nOutput ONLY one complete <svg> element, no markdown and no commentary. Use viewBox='0 0 ${W} ${H}', layered shapes, gradients, glow filters, depth and rich detail. No script, no external images or fonts, no text unless asked.`,{signal:aiCtl.signal,modelTier:'complex',cache:false,onText:({text})=>{st.textContent='Painting with AI... '+Math.round(text.length/1000)+'k chars'}});const m=r.text.match(/<svg[\s\S]*<\/svg>/i);if(m)svg=m[0]}}catch(e){console.warn(e)}
 if(!svg){svg=fbSvg(p,W,H);mode='Offline art mode (AI unavailable)'}
 svg=svg.replace(/<svg[^>]*>/,t=>(/xmlns=/.test(t)?t:t.replace('<svg','<svg xmlns="http://www.w3.org/2000/svg"')).replace(/\s(width|height)="[^"]*"/g,'').replace('<svg',`<svg width="${W}" height="${H}"`));
 aiSvg=svg;$('#aipv').src=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml'}));st.textContent=mode+' · ready';$('#aiu').disabled=$('#aiv').disabled=false;b.disabled=false};
function aiAdd(tl){const img=new Image();img.onload=()=>{const c=document.createElement('canvas');c.width=S.w;c.height=S.h;c.getContext('2d').drawImage(img,0,0,S.w,S.h);c.toBlob(bl=>{const id=uid(),url=URL.createObjectURL(bl),m={id,name:'AI '+$('#aip').value.trim().slice(0,22)+'.png',type:'image',dur:5,url};blobs[id]=url;S.media.push(m);if(tl)addClip(m,0,S.t);else rBin();aiEl.classList.remove('on');toast(tl?'AI image added to the timeline':'AI image added to Project Media')},'image/png')};img.onerror=()=>toast('That image could not be rendered. Try Generate again.');img.src=$('#aipv').src}
$('#aiu').onclick=()=>aiAdd(0);$('#aiv').onclick=()=>aiAdd(1);
/* layouts + save helper */
function setLay(i){set.lay=i;st.set('en_set',set);$('#editor').dataset.l=i;$('#lay').value=i}
$('#lay').onchange=e=>setLay(+e.target.value);
$('#lrand').onclick=()=>{let i;do{i=Math.floor(Math.random()*5)}while(i==set.lay);setLay(i);toast($('#lay').selectedOptions[0].text)};
async function saveFile(b,name){let dl=null;try{dl=window.claude&&await window.claude.use('downloads')}catch(e){}
 if(dl){try{await dl.save({filename:name,data:b});toast('Saved '+name)}catch(e){toast('Save cancelled')}return}
 const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;a.click()}
/* design studio: image, logo, thumbnail, banner */
const DT={image:[1280,720],logo:[800,800],thumbnail:[1280,720],banner:[2560,1440]};
let D={type:'thumbnail',bg:'#14143a',bg2:'#ff3d9a',grad:1,L:[],sel:null,init:0},dr=null;const dcv=$('#dcv'),dg=dcv.getContext('2d');
const mkD=o=>Object.assign({id:uid(),k:'text',x:60,y:60,w:300,h:120,c:'#ffffff',text:'YOUR TITLE',size:120,op:100,br:100,co:100,sa:100,rad:0,sh:1,st:1,circ:0,ctr:0},o);
const TP=[(W,H,a,b)=>[mkD({k:'rect',w:W*.04,h:H,x:0,y:0,c:a}),mkD({text:'BIG IDEA',x:W*.08,y:H*.28,size:H*.2}),mkD({text:'subtitle goes here',x:W*.08,y:H*.58,size:H*.07,c:b,st:0,sh:0})],
(W,H,a,b)=>[mkD({k:'circle',x:W/2-H*.3,y:H*.2,w:H*.6,h:H*.6,c:a}),mkD({text:'LOGO',ctr:1,y:H*.41,size:H*.16,st:0})],
(W,H,a,b)=>[mkD({k:'rect',x:0,y:H*.62,w:W,h:H*.22,c:a,op:90}),mkD({text:'NEW VIDEO EVERY WEEK',ctr:1,y:H*.66,size:H*.1,st:0}),mkD({text:'WATCH NOW',ctr:1,y:H*.2,size:H*.2,c:b})],
(W,H,a,b)=>[mkD({k:'rect',x:W*.5,y:0,w:W*.5,h:H,c:a,op:80}),mkD({text:'TOP 10',x:W*.06,y:H*.18,size:H*.3}),mkD({text:'YOU MUST SEE',x:W*.06,y:H*.55,size:H*.1,c:b})],
(W,H,a,b)=>[mkD({k:'rect',x:W*.05,y:H*.08,w:W*.9,h:H*.84,c:'#000000',op:35,rad:H*.06}),mkD({text:'EPIC MOMENT',ctr:1,y:H*.38,size:H*.16}),mkD({k:'circle',x:W*.85,y:H*.1,w:H*.14,h:H*.14,c:b})]];
const PAL=[['#ff3d9a','#00d4ff'],['#9b5cff','#ffd000'],['#00c8ff','#ff3d9a'],['#ff7a00','#ffffff'],['#00d68f','#ffe600']],BG=['#0d0d2b','#1a0b2e','#06202b','#240b0b','#0b2416'];
function dTpl(i){const W=dcv.width,H=dcv.height,p=PAL[Math.floor(Math.random()*5)];D.bg=BG[Math.floor(Math.random()*5)];D.bg2=p[0];D.grad=1;D.L=TP[i](W,H,p[0],p[1]);D.sel=null;$('#dbg').value=D.bg;$('#dbg2').value=D.bg2;$('#dgr').checked=true;dProps();dDraw()}
function dType(t){D.type=t;[dcv.width,dcv.height]=DT[t];document.querySelectorAll('#dty button').forEach(b=>b.classList.toggle('on',b.dataset.t==t));D.L.length?dDraw():dTpl(Math.floor(Math.random()*5))}
function dInit(){if(D.init)return dDraw();D.init=1;$('#dty').innerHTML=Object.keys(DT).map(k=>`<button data-t='${k}'>${k[0].toUpperCase()+k.slice(1)}</button>`).join('');document.querySelectorAll('#dty button').forEach(b=>b.onclick=()=>dType(b.dataset.t));dType('thumbnail')}
function dDraw(ns){const W=dcv.width,H=dcv.height;dg.globalAlpha=1;dg.filter='none';
 if(D.grad){const gr=dg.createLinearGradient(0,0,W,H);gr.addColorStop(0,D.bg);gr.addColorStop(1,D.bg2);dg.fillStyle=gr}else dg.fillStyle=D.bg;dg.fillRect(0,0,W,H);
 for(const l of D.L){dg.save();dg.globalAlpha=l.op/100;dg.filter=`brightness(${l.br}%) contrast(${l.co}%) saturate(${l.sa}%)`;dg.fillStyle=l.c;dg.beginPath();
  if(l.k=='text'){dg.font=`800 ${l.size}px 'Space Grotesk',system-ui,sans-serif`;dg.textBaseline='top';l.w=dg.measureText(l.text).width;l.h=l.size*1.1;if(l.ctr)l.x=(W-l.w)/2;
   if(l.sh){dg.shadowColor='#000c';dg.shadowBlur=l.size/4;dg.shadowOffsetY=l.size/20}if(l.st){dg.lineWidth=l.size/7;dg.strokeStyle='#000';dg.lineJoin='round';dg.strokeText(l.text,l.x,l.y)}dg.fillText(l.text,l.x,l.y)}
  else{if(l.k=='circle'||l.circ)dg.ellipse(l.x+l.w/2,l.y+l.h/2,l.w/2,l.h/2,0,0,7);else dg.roundRect(l.x,l.y,l.w,l.h,l.rad);
   if(l.k=='img'){dg.clip();const im=l.img,s=Math.max(l.w/im.width,l.h/im.height),iw=im.width*s,ih=im.height*s;dg.drawImage(im,l.x+(l.w-iw)/2,l.y+(l.h-ih)/2,iw,ih)}else dg.fill()}
  dg.restore()}
 const l=D.L.find(x=>x.id==D.sel);if(l&&!ns){dg.save();dg.strokeStyle='#00d4ff';dg.lineWidth=Math.max(2,W/500);dg.setLineDash([W/100,W/200]);dg.strokeRect(l.x,l.y,l.w,l.h);dg.fillStyle='#00d4ff';const h=W/60;dg.fillRect(l.x+l.w-h/2,l.y+l.h-h/2,h,h);dg.restore()}}
const dpt=e=>{const r=dcv.getBoundingClientRect();return[(e.clientX-r.left)*dcv.width/r.width,(e.clientY-r.top)*dcv.height/r.height]};
dcv.onpointerdown=e=>{const[x,y]=dpt(e),hs=dcv.width/40;let l=D.L.find(q=>q.id==D.sel);
 if(l&&x>l.x+l.w-hs&&x<l.x+l.w+hs&&y>l.y+l.h-hs&&y<l.y+l.h+hs)dr={m:'r',l,x,y,w:l.w,h:l.h,s:l.size};
 else{l=[...D.L].reverse().find(q=>x>=q.x&&x<=q.x+q.w&&y>=q.y&&y<=q.y+q.h);D.sel=l?l.id:null;if(l)dr={m:'m',l,x,y,ox:l.x,oy:l.y}}
 dcv.setPointerCapture(e.pointerId);dProps();dDraw()};
dcv.onpointermove=e=>{if(!dr)return;const[x,y]=dpt(e),l=dr.l;if(dr.m=='m'){l.ctr=0;l.x=dr.ox+x-dr.x;l.y=dr.oy+y-dr.y}else if(l.k=='text')l.size=Math.max(10,dr.s*(1+(x-dr.x)/Math.max(dr.w,50)));else{l.w=Math.max(20,dr.w+x-dr.x);l.h=Math.max(20,dr.h+y-dr.y)}dDraw()};
dcv.onpointerup=()=>{if(dr&&dr.m=='r')dProps();dr=null};
function dProps(){const p=$('#dpr'),l=D.L.find(x=>x.id==D.sel);if(!l){p.innerHTML='<p class=mu>Click a layer on the canvas, or add text, shapes and images. Drag to move, drag the corner square to resize.</p>';return}
 const R=(k,n,a,b)=>`<div class='f'><label>${n}</label><input type='range' data-k='${k}' min='${a}' max='${b}'><span></span></div>`,C=(k,n)=>`<div class='f'><label>${n}</label><input type='checkbox' data-k='${k}'></div>`,t=l.k=='text';
 p.innerHTML=(t?`<div class='f'><label>Text</label><input type='text' data-k='text'></div>`+R('size','Size',10,Math.round(dcv.height/2))+C('sh','Shadow')+C('st','Outline'):'')+`<div class='f'><label>Color</label><input type='color' data-k='c'></div>`+R('op','Opacity',0,100)+(t?'':R('rad','Round',0,300)+R('w','Width',20,dcv.width)+R('h','Height',20,dcv.height))+(l.k=='img'?C('circ','Circle crop')+R('br','Brightness',0,200)+R('co','Contrast',0,200)+R('sa','Saturation',0,300):'')+`<div class='tb'><button data-a='up'>⬆ Front</button><button data-a='dn'>⬇ Back</button><button data-a='dup'>Duplicate</button><button data-a='del'>Delete</button></div>`;
 p.querySelectorAll('[data-k]').forEach(el=>{const k=el.dataset.k;if(el.type=='checkbox')el.checked=!!l[k];else el.value=l[k];el.oninput=()=>{l[k]=el.type=='checkbox'?+el.checked:el.type=='range'?+el.value:el.value;dDraw()}});
 p.querySelectorAll('[data-a]').forEach(b=>b.onclick=()=>{const i=D.L.indexOf(l),a=b.dataset.a;if(a=='del'){D.L.splice(i,1);D.sel=null}if(a=='up'&&i<D.L.length-1)D.L.push(D.L.splice(i,1)[0]);if(a=='dn'&&i>0)D.L.unshift(D.L.splice(i,1)[0]);if(a=='dup'){const c={...l,id:uid(),x:l.x+30,y:l.y+30,ctr:0};D.L.push(c);D.sel=c.id}dProps();dDraw()})}
const dAdd=l=>{D.L.push(l);D.sel=l.id;dProps();dDraw()};
$('#dtx').onclick=()=>dAdd(mkD({text:'NEW TEXT',x:dcv.width*.1,y:dcv.height*.4,size:dcv.height*.12}));
$('#drc').onclick=()=>dAdd(mkD({k:'rect',x:dcv.width*.2,y:dcv.height*.3,w:dcv.width*.4,h:dcv.height*.3,c:'#00d4ff',rad:30}));
$('#dci').onclick=()=>dAdd(mkD({k:'circle',x:dcv.width*.4,y:dcv.height*.3,w:dcv.height*.3,h:dcv.height*.3,c:'#ff3d9a'}));
$('#dim').onclick=()=>$('#dfi').click();
$('#dfi').onchange=e=>{[...e.target.files].forEach(f=>{const im=new Image();im.onload=()=>{const W=dcv.width,H=dcv.height,first=!D.L.some(x=>x.k=='img'),w=first?W:W*.45,l=mkD({k:'img',img:im,x:first?0:W*.1,y:first?0:H*.1,w,h:first?H:w*im.height/im.width});if(first)D.L.unshift(l);else D.L.push(l);D.sel=l.id;dProps();dDraw()};im.src=URL.createObjectURL(f)});e.target.value=''};
$('#dbg').oninput=e=>{D.bg=e.target.value;dDraw()};$('#dbg2').oninput=e=>{D.bg2=e.target.value;dDraw()};$('#dgr').onchange=e=>{D.grad=+e.target.checked;dDraw()};
$('#drnd').onclick=()=>dTpl(Math.floor(Math.random()*5));
const dBlob=()=>{dDraw(1);return new Promise(r=>dcv.toBlob(b=>{dDraw();r(b)},'image/png'))};
$('#dsv').onclick=async()=>saveFile(await dBlob(),D.type+'-editnova.png');
$('#dto').onclick=async()=>{const b=await dBlob();if(!S.id)newProject('Untitled project');const id=uid(),url=URL.createObjectURL(b);blobs[id]=url;S.media.push({id,name:'Design '+D.type+'.png',type:'image',dur:5,url});nav('editor');toast('Design added to Project Media')};
/* templates page */
const TPLS=[['YouTube 16:9','Video',1280,720,'▶','v'],['Shorts / Reels 9:16','Video',720,1280,'📱','v'],['Square 1:1','Video',1080,1080,'⬛','v'],['Cinema 21:9','Video',1680,720,'🎬','v'],['Full HD 1080p','Video',1920,1080,'🖥','v'],['Gaming Montage','Video',1280,720,'🎮','v'],['Instagram Story','Social',1080,1920,'📸','v'],['TikTok Vertical','Social',1080,1920,'🎵','v'],['Facebook Feed 4:5','Social',1080,1350,'👍','v'],['Podcast Clip','Social',1080,1080,'🎙','v'],['YouTube Thumbnail','Design',1280,720,'🖼','thumbnail',0],['Logo Badge','Design',800,800,'⭐','logo',1],['Channel Banner','Design',2560,1440,'🏷','banner',2],['Split Thumbnail','Design',1280,720,'🔥','thumbnail',3],['Photo Edit','Design',1280,720,'🖌','image',4]];
let tf='All';
function rTpls(){const f=$('#tfl');f.innerHTML=['All','Video','Social','Design'].map(c=>`<button class='${c==tf?'pri':''}' data-c='${c}'>${c}</button>`).join('');f.querySelectorAll('button').forEach(b=>b.onclick=()=>{tf=b.dataset.c;rTpls()});
 const g=$('#tall');g.innerHTML='';TPLS.filter(t=>tf=='All'||t[1]==tf).forEach(t=>{const[n,cat,w,h,ico,k,tp]=t,d=document.createElement('div'),hue=TPLS.indexOf(t)*47%360;d.className='card t';
  d.innerHTML=`<div class='tpw'><div class='tpv' style='width:${Math.min(88,w/h*50)}%;aspect-ratio:${w}/${h};background:linear-gradient(135deg,hsl(${hue} 70% 22%),hsl(${(hue+60)%360} 80% 45%))'><span class='ico'>${ico}</span></div></div><b>${n}</b><div class='mu'>${cat} · ${w}×${h}</div>`;
  d.onclick=()=>{if(k=='v')newProject(n,w,h);else{nav('studio');dType(k);dTpl(tp)}};g.append(d)})}
$('#tplh').onclick=()=>nav('templates');
/* export dialog: own video + image */
let exC=false,exTm=null;
function exTab(t){$('#epv').style.display=t=='v'?'':'none';$('#epi').style.display=t=='i'?'':'none';$('#etv').classList.toggle('pri',t=='v');$('#eti').classList.toggle('pri',t=='i')}
function exInfo(){const tot=total();$('#evi').textContent=`${tcf(tot)} · ${S.w}×${S.h} · about ${(+$('#evq').value*tot/8e6).toFixed(1)} MB`}
function openEx(){if(!S.id)return toast('Open a project first');const f=$('#evf');f.innerHTML='';let mp=0;
 [['video/webm;codecs=vp9,opus','WebM · VP9 (best quality)','webm'],['video/webm;codecs=vp8,opus','WebM · VP8 (most compatible)','webm'],['video/mp4;codecs=avc1.42E01E,mp4a.40.2','MP4 · H.264','mp4'],['video/mp4','MP4','mp4']].forEach(([m,n,e])=>{if(window.MediaRecorder&&MediaRecorder.isTypeSupported(m)&&!(e=='mp4'&&mp)){const o=new Option(n,m);o.dataset.e=e;f.add(o);if(e=='mp4')mp=1}});
 if(!f.options.length){const o=new Option('WebM','video/webm');o.dataset.e='webm';f.add(o)}
 $('#evn').value=$('#ein').value=S.name.replace(/\W+/g,'_');$('#eit').value=S.t.toFixed(2);exInfo();exTab('v');$('#exm').classList.add('on')}
$('#ex').onclick=openEx;$('#etv').onclick=()=>exTab('v');$('#eti').onclick=()=>exTab('i');$('#evq').onchange=exInfo;
$('#exx').onclick=()=>{if(rec)return toast('Rendering... press Cancel first');$('#exm').classList.remove('on')};
$('#evg').onclick=()=>{if(!window.MediaRecorder)return toast('Video export is not supported in this browser');const tot=total();if(!tot)return toast('Add clips to the timeline first');
 pause();initAC();ac.resume();exC=false;const fps=+$('#evr').value,mime=$('#evf').value,ext=$('#evf').selectedOptions[0].dataset.e,stream=cv.captureStream(fps);if($('#eva').checked)dst.stream.getAudioTracks().forEach(t=>stream.addTrack(t));
 const ch=[],r=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:+$('#evq').value,audioBitsPerSecond:192000});rec=r;r.ondataavailable=e=>e.data.size&&ch.push(e.data);
 r.onstop=()=>{clearInterval(exTm);$('#evg').disabled=false;$('#evc').disabled=true;if(exC){$('#evb').style.width='0';return toast('Export cancelled')}$('#evb').style.width='100%';saveFile(new Blob(ch,{type:mime.split(';')[0]}),($('#evn').value||'video')+'.'+ext)};
 $('#evg').disabled=true;$('#evc').disabled=false;$('#evb').style.width='0';exTm=setInterval(()=>{$('#evb').style.width=Math.min(100,S.t/tot*100)+'%'},150);seek(0);r.start();play();toast('Rendering in real time. Keep this tab open.')};
$('#evc').onclick=()=>{exC=true;pause();if(rec){rec.stop();rec=null}};
$('#eig').onclick=()=>{const t=parseFloat($('#eit').value)||0,mt=$('#eif').value,ext={'image/png':'png','image/jpeg':'jpg','image/webp':'webp'}[mt];pause();seek(t);setTimeout(()=>{frame();cv.toBlob(b=>saveFile(b,($('#ein').value||'frame')+'.'+ext),mt,$('#eiq').value/100)},500)};
$('#dsv').onclick=async()=>{const f=$('#dfm').value,mt={PNG:'image/png',JPG:'image/jpeg',WebP:'image/webp'}[f];dDraw(1);const b=await new Promise(r=>dcv.toBlob(x=>{dDraw();r(x)},mt,.95));saveFile(b,D.type+'-editnova.'+f.toLowerCase())};
setLay(set.lay||0);
nav('home');